<?php

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "testing_recit_140P";
$DB_CHARSET = "utf8mb4";

$dsn = "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=$DB_CHARSET";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,    // Error mode: throw exceptions
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,          // Fetch as associative array
    PDO::ATTR_EMULATE_PREPARES   => false,                     // Use native prepares
];

try {
    $con = new PDO($dsn, $DB_USER, $DB_PASS, $options);
    // echo "Connected successfully"; // Optional: keep for debugging
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
    exit;
}
?>
