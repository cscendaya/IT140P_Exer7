<?php
class DataHandler {
    /*private $mysqli;

    public function __construct($mysqli) {
        $this->mysqli = $mysqli;
    }*/

    protected $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    //needed kasi dito ung mysqli connection, so i gotta learn how to use pdo ugh
    /*public function callProcedure($procedure, $params = []) {
        $placeholders = implode(',', array_fill(0, count($params), '?'));
        $sql = "CALL $procedure($placeholders)";
        $stmt = $this->mysqli->prepare($sql);

        if ($stmt && $params) {
            $types = str_repeat('s', count($params)); // assume all are strings
            $stmt->bind_param($types, ...$params);
        }

        $data = [];

        if ($stmt && $stmt->execute()) {
            $result = $stmt->get_result();
            $data = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
            $stmt->close();
        } else {
            $data = ['error' => $stmt ? $stmt->error : $this->mysqli->error];
        }

        // Clear any remaining results (needed for stored procedures)
        while ($this->mysqli->more_results() && $this->mysqli->next_result()) {
            $this->mysqli->use_result();
        }

        return $data;
    }*/
    
    public function callProcedure($name, $params = []) {
        try {
            $placeholders = implode(',', array_fill(0, count($params), '?'));
            $stmt = $this->pdo->prepare("CALL $name($placeholders)");
            $stmt->execute($params);

            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        } catch (PDOException $e) { //why is it like this I DONTGET PDO AT ALL
            // Re-throw as generic Exception so we can catch it at the controller level
            throw new Exception($e->getMessage());
        }
    }

    public function getCleanErrorMessage($errorMessage) {
    return preg_replace('/^SQLSTATE\[\w+\]:.*?: \d+ /', '', $errorMessage);
    }


    public function json($data) {
        header('Content-Type: application/json');
        echo json_encode($data);
    }
}
