<?php
class CRUD {
    private $mysqli;

    public function __construct($mysqli) {
        $this->mysqli = $mysqli;
    }

    // Call a stored procedure with optional param types and arguments
    //public function callProcedure($procedureName, $paramTypes = '', ...$params) {
    //    $placeholders = implode(',', array_fill(0, count($params), '?'));
    //    $query = "CALL $procedureName($placeholders)";
    //    return $this->executeQuery($query, $paramTypes, ...$params);
    //}

    // General-purpose SELECT, INSERT, UPDATE, DELETE
    public function executeQuery($query, $paramTypes = '', ...$params) {
        $stmt = $this->mysqli->prepare($query);
        if (!$stmt) {
            return ['error' => 'Prepare failed: ' . $this->mysqli->error];
        }

        if ($paramTypes && $params) {
            $stmt->bind_param($paramTypes, ...$params);
        }

        if (!$stmt->execute()) {
            return ['error' => 'Execute failed: ' . $stmt->error];
        }

        $result = $stmt->get_result();
        $data = [];

        if ($result) {
            $data = $result->fetch_all(MYSQLI_ASSOC);
        }

        $stmt->close();

        // Handle any remaining results for stored procedures
        while ($this->mysqli->more_results() && $this->mysqli->next_result()) {
            $this->mysqli->use_result();
        }

        return $data;
    }

    // Used for insert/update/delete when you only care about success/failure
    public function executeNonQuery($query, $paramTypes = '', ...$params) {
        $stmt = $this->mysqli->prepare($query);
        if (!$stmt) {
            return ['error' => 'Prepare failed: ' . $this->mysqli->error];
        }

        if ($paramTypes && $params) {
            $stmt->bind_param($paramTypes, ...$params);
        }

        if (!$stmt->execute()) {
            return ['error' => 'Execute failed: ' . $stmt->error];
        }

        $affected = $stmt->affected_rows;
        $stmt->close();

        return ['affected_rows' => $affected];
    }

    // Utility function if you need last insert ID
    public function getLastInsertId() {
        return $this->mysqli->insert_id;
    }
}
