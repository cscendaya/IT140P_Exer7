<?php
/*require_once 'classes/database.php';
require_once 'classes/datahandler.php';


$dataHandler = new DataHandler($con);

$requestMethod = $_SERVER['REQUEST_METHOD'];

switch ($requestMethod) {
    case 'GET':
        getSubjects($dataHandler);
        break;
    case 'POST':
        createSubject($dataHandler);
        break;
    case 'PUT':
        updateSubject($dataHandler);
        break;
    case 'DELETE':
        deleteSubject($dataHandler);
        break;
    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method Not Allowed']);
}*/

function getSubjects($dataHandler) {
    $result = $dataHandler->callProcedure('get_subjects', []);
    $dataHandler->json($result);
    //add try catch here :)
}

function createSubject($dataHandler) {
    try {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? '';
    $name = $data['name'] ?? '';
    error_log("Creating subject: $id - $name");
    $result = $dataHandler->callProcedure('insert_subject', [$id, $name]);
    $dataHandler->json(['message' => 'Subject is added successfully.', 'result' => $result]);

    } catch (Exception $e) { //why is it like this
        http_response_code(400);
        $dataHandler->json(['error' => $e->getMessage()]);
    }
}



/*function updateSubject($dataHandler) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? '';
    $name = $data['new_name'] ?? '';
    $result = $dataHandler->callProcedure('update_subject', [$id, $new_name]);
    $dataHandler->json($result);
}*/

/*function updateSubject($dataHandler) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? '';
    $new_name = $data['new_name'] ?? '';

    try {
        $result = $dataHandler->callProcedure('update_subject', [$id, $new_name]);

        // Return success message
        $dataHandler->json(['message' => 'Subject updated successfully.']);
    } catch (Exception $e) {
        // This will catch the SIGNAL error and return it in JSON
        http_response_code(400);
        $dataHandler->json(['error' => $e->getMessage()]);
    }
}*/

function updateSubject($dataHandler) {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? '';
        $new_name = $data['new_name'] ?? '';
        $result = $dataHandler->callProcedure('update_subject', [$id, $new_name]);

        if (!is_null($result)) {
            $dataHandler->json(['message' => 'Subject is updated successfully.']);
        }
       

    } 
    catch (Exception $e) {
    http_response_code(400);
    $cleanMessage = $dataHandler->getCleanErrorMessage($e->getMessage());
    $dataHandler->json(['error' => $cleanMessage]);
    }

}



function deleteSubject($dataHandler) {
    try {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? '';
    $result = $dataHandler->callProcedure('delete_subject', [$id]);
    if (!is_null($result)) {
            $dataHandler->json(['message' => 'Subject is updated successfully.']);
        }
    } catch (Exception $e) {
        http_response_code(400);
        $dataHandler->json(['error' => $e->getMessage()]);
    }
}
