<?php
require_once 'classes/database.php';
require_once 'classes/datahandler.php';

$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$basePath = '/recit_testing_140p'; // <-- your app folder
$relativePath = str_replace($basePath, '', $path);

$method = $_SERVER['REQUEST_METHOD'];

$routes = [
  'GET' => [
    '/subjects'  => ['file' => 'routes/subjects.php',  'function' => 'getSubjects'],
    '/sections'  => ['file' => 'routes/sections.php',  'function' => 'getSections'],//
    '/students'  => ['file' => 'routes/students.php',  'function' => 'getStudents'],//
    '/questions' => ['file' => 'routes/questions.php', 'function' => 'getQuestions'],//
  ],
  'POST' => [
    '/subjects'  => ['file' => 'routes/subjects.php',  'function' => 'createSubject'],
    '/sections'  => ['file' => 'routes/sections.php',  'function' => 'createSection'],//
    '/students'  => ['file' => 'routes/students.php',  'function' => 'createStudent'],//
    '/questions' => ['file' => 'routes/questions.php', 'function' => 'createQuestion'],//
  ],
  'PUT' => [
    '/subjects'  => ['file' => 'routes/subjects.php',  'function' => 'updateSubject'],//
    '/sections'  => ['file' => 'routes/sections.php',  'function' => 'updateSection'],//
    '/students'  => ['file' => 'routes/students.php',  'function' => 'updateStudent'],//
    '/questions' => ['file' => 'routes/questions.php', 'function' => 'updateQuestion'],//
  ],
  'DELETE' => [
    '/subjects'  => ['file' => 'routes/subjects.php',  'function' => 'deleteSubject'],//
    '/sections'  => ['file' => 'routes/sections.php',  'function' => 'deleteSection'],//
    '/students'  => ['file' => 'routes/students.php',  'function' => 'deleteStudent'],//
    '/questions' => ['file' => 'routes/questions.php', 'function' => 'deleteQuestion'],//
  ],
];


if (isset($routes[$method][$relativePath])) {
    $route = $routes[$method][$relativePath];
    require_once $route['file'];
    call_user_func($route['function'], new DataHandler($con));
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Route not found']);
}
